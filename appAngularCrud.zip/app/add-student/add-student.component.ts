import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { StudentsService } from '../students.service';

@Component({
  selector: 'app-add-student',
  templateUrl: './add-student.component.html',
  styleUrls: ['./add-student.component.css']
})
export class AddStudentComponent implements OnInit {
  empFrom: FormGroup;
  constructor(private formbuilder:FormBuilder,private studentservice:StudentsService) { }
  
  ngOnInit(): void {
    this.init();
  }
  public saveStudent():void{
    // console.log(this.studFrom.get('stu_id').value)
    // var formData: any = new FormData();
    // formData.append("stu_id", this.studFrom.get('stu_id').value);
    // formData.append("stu_name", this.studFrom.get('stu_name').value);
    // formData.append("stu_age", this.studFrom.get('stu_age').value);
    // console.log(formData)
    this.studentservice.AddStudent(this.empFrom).subscribe(data=>alert(data));
    window.location.href = "http://localhost:4200/add-student/";
  }
  private init():void{
    this.empFrom=this.formbuilder.group({
      empId: [],
      empName: [],
      empCity: []
    })
  }
}
