export interface Employee {
    empId: any,
    empName: any,
    empCity: any,
}
