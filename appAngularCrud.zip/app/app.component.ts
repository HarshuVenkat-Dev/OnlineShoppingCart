import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { StudentsService } from './students.service';
import { Employee } from './employee';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  constructor(private __studentsService:StudentsService){}
  employees: any;
  title= 'crud';
  
  ngOnInit(){
    this.__studentsService.getStudents().subscribe(data => this.employees = data)
  }
  deleteItem(post: any){
    alert("Success"+post)
    this.__studentsService.deletePost(post)
        .subscribe(data => alert(data));
        window.location.href = "http://localhost:4200/";

  }
}
