import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Employee} from './employee';
import { Observable } from 'rxjs';



@Injectable({
  providedIn: 'root'
})
export class StudentsService {

  constructor(private http:HttpClient){}
  employees:any;
  getStudents():Observable<Employee[]>{
  return this.http.get<Employee[]>("https://localhost:44397/Employee/Get");
  
  }

  public AddStudent(studata:any):Observable<any>{
    
  //  let header = new HttpHeaders()

  //   .append('Accept', '*/*')
    
  //   .append('Content-Type', 'application/json')
    
  //   .append('Access-Control-Allow-Origin', '*')
    
  //   .append('Set-Cookie', 'SameSite=None')
  //   .append('Access-Control-Allow-Headers', 'Content-Type')
  //   .append('Access-Control-Allow-Methods', 'GET,POST,OPTIONS,DELETE,PUT');
    
     let formObj = studata.getRawValue(); 
  //   console.log(formObj)
  //   const body = JSON.stringify(formObj);
  //   console.log(body)
    
    

 // let header = new Headers().append('Content-Type', 'application/x-www-form-urlencoded'); 
//  var params = new URLSearchParams();
//         params.set('stu_id', '102');
//         params.set('stu_name', 'foo');
//         params.set('stu_age', 'foo');
  

//  return this._http.post('http://localhost:6579/api/PostUser', params.toString(), { headers: headers }).map(res => res.json());
    return this.http.post("https://localhost:44397/Employee/Post", formObj);
    }

    deletePost(id:any):Observable<any>{
      alert(id)
      return this.http.delete("https://localhost:44397/Employee/Delete/"+id);
        
    }
  
}
